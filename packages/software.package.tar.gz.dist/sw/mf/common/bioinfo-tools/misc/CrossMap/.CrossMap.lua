conflict("CrossMap")
whatis("Load CrossMap environment")



-- need version and cluster
local myVer
myVer = myModuleVersion()

local cluster
local hostname
hostname=capture("hostname")
cluster=hostname:gsub("[0-9]+%.uppmax.uu.se", "")

--DEBUG:
--LmodMessage("hostname: " .. hostname)
--LmodMessage("cluster: " .. cluster)

-- TODO need to set paths, should set cluster and version as vars, see e.g. openmpi lua modules...
--prepend_path("PATH", "/sw/apps/bioinfo/CrossMap/0.1.2/milou/sw/comp/python/2.7.4/bin")
--prepend_path("PYTHONPATH", "/sw/apps/bioinfo/CrossMap/0.1.2/milou/sw/comp/python/2.7.4/lib/python2.7/site-packages")
prepend_path("PATH", pathJoin("/sw/apps/bioinfo/CrossMap/", myVer, "/", cluster, "/sw/comp/python/2.7.4/bin"))
prepend_path("PYTHONPATH", pathJoin("/sw/apps/bioinfo/CrossMap/", myVer, "/", cluster, "/sw/comp/python/2.7.4/lib/python2.7/site-packages"))


if (mode() == "load") then
    if ( not (isloaded("python/2.7.4"))) then
       LmodMessage("Loading module python/2.7.4")
       load "python/2.7.4"	 
    end
end

--[[

see installation in README.md


--]]
