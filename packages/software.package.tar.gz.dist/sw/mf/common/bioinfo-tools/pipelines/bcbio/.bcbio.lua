conflict("bcbio")
whatis("Load bcbio environment")

if (mode() == "load") then
   LmodMessage ("\nThis is a development version of bcbio-nextgen\n\n")

   LmodMessage ("Now you must run: ")
   LmodMessage ("source /sw/apps/bioinfo/bcbio/20150205/milou/source.sh")
   LmodMessage ("to prepare environment and load paths for bcbio\n\n")

   LmodMessage ("See http://bcbio-nextgen.readthedocs.org/en/latest/contents/testing.html")
   LmodMessage ("for example configuration and pipelines\n")


   LmodMessage ("Please report any issues with this installation to pall.olason@scilifelab.se")

end

--[[

cant have this:
#source /sw/apps/bioinfo/bcbio/20150205/milou/virtualenv-12.0.7/VE-2.7.1/bin/activate

--]]
