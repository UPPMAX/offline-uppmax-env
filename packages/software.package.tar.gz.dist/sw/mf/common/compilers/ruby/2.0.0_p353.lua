-- family("compilers")

whatis("Loads ruby")

io = require("io")
os = require("os")

local stdout = io.stdout

-- stdout:write("ulimit -v unlimited ; \n")

ruby_root = "/sw/comp/ruby/" .. os.getenv("MODULES_MACH")  .. "/" ..  myModuleVersion()

-- Lmod magic inverts these on unloading.

prepend_path("MANPATH",         pathJoin(ruby_root, "share/man"))
prepend_path("PATH",            pathJoin(ruby_root, "bin"))
prepend_path("PATH", 		os.getenv("HOME") .. "/.gem/ruby/2.0.0/bin")
-- prepend_path("LD_LIBRARY_PATH", pathJoin(ruby_root, "lib"))

-- setenv("JAVA_HOME",javapath)
