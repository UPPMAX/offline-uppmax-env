family("compilers")

whatis("Loads java")

io = require("io")
os = require("os")

local stdout = io.stdout

-- stdout:write("ulimit -v unlimited ; \n")

javapath = "/sw/comp/java/" .. os.getenv("MODULES_MACH")  .. "/" ..  myModuleVersion()

-- Lmod magic inverts these on unloading.

prepend_path("MANPATH",         pathJoin(javapath, "man"))
prepend_path("PATH",            pathJoin(javapath, "bin"))
-- prepend_path("LD_LIBRARY_PATH", pathJoin(mpipath, "lib"))

setenv("JAVA_HOME",javapath)
setenv("JDK_HOME",javapath)
