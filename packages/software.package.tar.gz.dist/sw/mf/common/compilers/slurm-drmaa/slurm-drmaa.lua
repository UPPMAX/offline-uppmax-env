
family("compilers")

whatis("Loads slurm-drmaa")

os = require("os")

basepath = "/sw/apps/build/slurm-drmaa/" .. myModuleVersion()


prepend_path("PATH",            pathJoin(basepath, "bin"), ":")
prepend_path("LD_RUN_PATH",            pathJoin(basepath, "lib"), ":")
prepend_path("LDFLAGS",   "-ldrmaa", " ")
prepend_path("LDFLAGS",   "-L" ..     pathJoin(basepath, "lib"), " ")
prepend_path("LDFLAGS",   "-Wl,-rpath=" ..  pathJoin(basepath, "lib"), " ")

prepend_path("CPPFLAGS",   "-I" ..  pathJoin(basepath, "include"), " ")


--setenv("JAVA_HOME",javapath)

