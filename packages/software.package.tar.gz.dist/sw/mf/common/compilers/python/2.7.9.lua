conflict("python")
whatis("Loads Python environment.")
prepend_path("PATH", "/proj/b2013006/sw/apps/python-2.7.8/bin")
prepend_path("MANPATH", "/proj/b2013006/sw/apps/python-2.7.8/share/man/")

--[[ 
Neither PYTHONHOME nor LD_LIBRARY_PATH should be set:

* If PYTHONHOME is set, this interferes when a user runs other Python
  interpreters. The correct PYTHONHOME is figured out by the interpreter
  anyway if the correct --prefix= parameter was given to the configure
  script.

* LD_LIBRARY_PATH also interferes with other Pythons. Especially when
  compiling extension modules, the wrong Python shared libraries may
  be picked up. Instead of LD_LIBRARY_PATH, embed the correct path to
  the shared library into the binary using the linker's -rpath option
  (see command below).

command line:

TARGET=/proj/b2013006/sw/apps/python-2.7.8
./configure --prefix=$TARGET --enable-shared LDFLAGS="-Wl,-rpath=$TARGET/lib"
make -j8 && make install

--]]
