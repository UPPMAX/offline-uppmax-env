family("parallel")

whatis("Sets up OpenMPI")

conflict("intelmpi")
local lfs = require("lfs")
local table = require("table")

local os = require("os")

local usedComp 
local compVer 
local myVer
local useVer 

myVer = myModuleVersion()

-- Any compiler loaded?
for a,comp in ipairs({"gcc","pgi","intel"}) do
  if (isloaded(comp)) then
    loadedmods = os.getenv("LOADEDMODULES")

    local index = loadedmods:find(comp .. '/')
    compVer = loadedmods:sub(index+string.len(comp .. '/'))

    if compVer:find(":") then
       compVer = compVer:sub(0,compVer:find(":")-1)
    end

    usedComp = comp
  end
end

-- No compiler used, default to system version

if (not usedComp) then
  load("gcc")
  usedComp = "gcc"
  compVer = "system"
end

-- 
if (usedComp == "gcc") then
  if (compVer == "system") then
    compVer = "9.2.0"
  end
  if (compVer == "4.7.3") then
    compVer = "4.7"
  end
  if (compVer == "4.8.2") then
    compVer = "4.8"
  end
  if (compVer == "4.8.2") then
    compVer = "4.8"
  end
end
if (usedComp == "pgi") then
  if (compVer == "2013") then
    compVer = "13.10"
  end
  if (compVer == "2014") then
    compVer = "14.3"
  end
  if (compVer == "2015") then
    compVer = "15.7"
  end
end

if (myVer == "1.6") then
  myVer = "1.6.5"
end
if (myVer == "1.7") then
  myVer = "1.7.4"
end

if (myVer == "default") then

  -- pathCompVer = compVer:gsub("%.","")

  supported = {}
  -- Check all installed 
  for n in lfs.dir("/opt/openmpi/") do

   -- Ends with compiler and version?
   if (n:match(usedComp .. compVer .. "$" )) then
     -- Get the openmpi version
     useVer = n:gsub(usedComp .. compVer .. "$", "")
     table.insert(supported, useVer)
   end
  end

  table.sort(supported)

  -- Sorted list, latest is last.
  if (table.getn(supported) > 0) then
    useVer = supported[ table.getn(supported) ]
  end

else
  -- Asked for a specific version?
  useVer = myVer
end


local mpipath= "/opt/openmpi/" .. useVer .. usedComp .. compVer

if (mode() == "load") then
 
  if (not lfs.attributes(mpipath)) then
    LmodError("Unfortunately, OpenMPI " .. useVer .. 
      " isn't available for " .. usedComp .. " version " .. compVer)
  end

end

-- Lmod magic inverts these on unloading.

prepend_path("MANPATH",         pathJoin(mpipath, "share/man"))
prepend_path("PATH",            pathJoin(mpipath, "bin"))
prepend_path("LD_LIBRARY_PATH", pathJoin(mpipath, "lib"))

setenv("MPI_ROOT",mpipath)
