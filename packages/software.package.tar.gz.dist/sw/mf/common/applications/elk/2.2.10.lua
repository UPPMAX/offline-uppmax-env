family("elk")
local pkghome = "/sw/apps/elk/2.2.10"
local pkgbin = "/sw/apps/elk/2.2.10/bin"
local pkgdocs = "/sw/apps/elk/2.2.10/docs"
if (mode() == "load") then
  if ( not (isloaded("intel/14.0") and isloaded("intelmpi/4.1") ) ) then
    LmodMessage("Loading modules intel/14.0 and intelmpi/4.1")
    load("intel/14.0", "intelmpi/4.1")
  end
end
prepend_path("PATH",pkgbin)
setenv("ELKHOME",pkghome)
setenv("ELKDOCS",pkgdocs)
whatis("General pourpose electronic structure code Elk. See documentation for more information.")
whatis("Compilation details: Hybrid Open MP and MPI parallel, libXC 2.02")
whatis("with compiler suite intel/14.0 and intelmpi/4.1 ")
whatis("URL: elk.sourceforge.net")

