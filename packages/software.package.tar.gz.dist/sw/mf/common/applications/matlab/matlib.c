/* fake username for matlab
 *     compile with gcc -fPIC -shared matlib.c -o matlib.so
 *     then start matlab with LD_PRELOAD=/....../matlib.so matlab
 * 32 dedicated matlab users starting with alfa at uid=42488
 */

#include <time.h>
#include <sys/types.h>
#include <pwd.h>
#include <string.h>
#include <stdio.h>

int makeuid() {
   return 42488+(time(0)&0x1f);
}

int getpwuid_r(uid_t uid, struct passwd *pwd, char *buf, size_t buflen, struct passwd **result){
static int Xgetpwuid_r=0;
char *sp=buf;
char fake_name[256];
char real_name[256];
struct passwd *real_pw, *fake_pw;
   ++Xgetpwuid_r;
//   printf("GETPWUID_R (call no %d)\n",Xgetpwuid_r);
   fake_pw=getpwuid(makeuid());
   strcpy(fake_name,fake_pw->pw_name);
   real_pw=getpwuid(uid);
   strcpy(real_name,real_pw->pw_name);
 //  printf("GETPWUID_R buf=%lx, buflen=%d, real_name=\"%s\", fake_name=\"%s\"\n",buf,buflen,real_name,fake_name);
   if(Xgetpwuid_r==1) {
      pwd->pw_name=strcpy(sp,fake_name); sp += strlen(sp)+1;
      }
   else {
      pwd->pw_name=strcpy(sp,real_name); sp += strlen(sp)+1;
      }
   pwd->pw_passwd=strcpy(sp,real_pw->pw_passwd); sp += strlen(sp)+1;
   pwd->pw_gecos=strcpy(sp,real_pw->pw_gecos); sp += strlen(sp)+1;
   pwd->pw_dir=strcpy(sp,real_pw->pw_dir); sp += strlen(sp)+1;
   pwd->pw_shell=strcpy(sp,real_pw->pw_shell); sp += strlen(sp)+1;
   pwd->pw_uid=real_pw->pw_uid;
   pwd->pw_gid=real_pw->pw_gid;
   *result=pwd;
   return 0;
}
