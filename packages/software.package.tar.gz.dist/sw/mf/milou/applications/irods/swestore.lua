--dofile("/sw/mf/common/includes/functions.lua")

family("irods")
whatis("Loads irods")

io = require("io")
os = require("os")
lfs = require("lfs")

local stdout = io.stdout
local stderr = io.stderr
local version = 3.2
--dofile("/sw/mf/common/includes/functions.lua")
--loadfile("/sw/mf/common/includes/functions.lua")

stderr:write("NB: the iRODS over Swestore/dCache service is being sunsetted.\n")
stderr:write("NB: please do not rely on it for storage of new data.\n")

function trim(s)
  return (s:gsub("^%s*(.-)%s*$", "%1"))
end

local irods_root = "/sw/apps/iRODS/icommands/"

--Log loading to syslog
--logToSyslog 
--log_to_syslog("irods")

-- lmod magic inverts these on unloading
prepend_path("PATH", pathJoin(irods_root, "/bin"))
prepend_path("PATH", "/sw/apps/iRODS/utils")

set_alias("iget", "iget -K")

local userid = trim(capture("exec id -u"))
local username = trim(capture("whoami"))
local home = "/home/" .. username .. "/"

setenv("irodsUserName", username)
setenv("irodsAuthScheme", "OS")

-- Set up tab completion in supported shells
local shell = os.getenv("SHELL") 
if shell == "/bin/bash" then
	stdout:write("source /sw/apps/iRODS/utils/irods_completion.bash \n")	
end

-- Choose a sensible default pwd
local groups = trim(capture("groups"))
local homeproj = "/"

for g in string.gmatch(groups, "%S+") do
	local matched_pattern = string.match(g, '[abgp]20[0-9]*') 
	if matched_pattern ~= nil and string.len(matched_pattern) == 8 then
		homeproj = g
	end
end 

if lfs.attributes(home .. "/.irods/") == nil then
	lfs.mkdir(home .. "/.irods")
end 

local setDir = true

local irodsCwd = os.getenv("irodsCwd")

if irodsCwd and irodsCwd ~= "" or lfs.attributes(home .. "/.irods/.irodsEnv") then
	setDir = false
end

setenv("irodsPort", "1250")
setenv("irodsZone", "ssUppnexZone")

if setDir then
	setenv("irodsCwd", "/ssUppnexZone/proj/" .. homeproj)
	setenv("irodsHome", "/ssUppnexZone/proj/" .. homeproj)
end

setenv("irodsDefResource", "swestoreArchResc")
setenv("irodsHost", "kali.uppmax.uu.se")

