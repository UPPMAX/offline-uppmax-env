family("rspt")
local pkghome = "/sw/apps/rspt/"
local pkgbin = "/sw/apps/rspt/milou/r1887"
local pkgdocs = "/sw/apps/rspt/docs/r1887"
if (mode() == "load") then
  if ( not (isloaded("intel/14.0") and isloaded("intelmpi/4.1") ) ) then
    LmodMessage("Loading modules intel/14.0 and intelmpi/4.1")
    load("intel/14.0", "intelmpi/4.1")
  end
end
prepend_path("PATH",pkgbin)
setenv("RSPTHOME",pkghome)
setenv("RSPTDOCS",pkgdocs)
whatis("General pourpose electronic structure code RSPt. See documentation for more information.")
whatis("Compilation details: MPI parallel with compiler suite intel/14.0 and intelmpi/4.1 ")
whatis("URL: www.fplmto-rspt.org")

