
#clu="common ra set osiris isis" 
#part="applications compilers environment libraries parallel" 
#for c in $clu; do for p in $part; do mkdir -p $c/$p; done; done 
# Add to this file/usr/local/Modules/default/init/.modulepath
# the 

#source this file first
#source /etc/profile.d/modules.sh

export MODULE_INCLUDE=/sw/share/mf/common/includes

#export MODULEPATH=/usr/local/Modules/versions:/usr/local/Modules/$MODULE_VERSION/modulefiles:/usr/local/Modules/modulefiles:/home/jukkak/mf/ra/applications:/home/jukkak/mf/ra/compilers:/home/jukkak/mf/ra/environment:/home/jukkak/mf/ra/libraries:/home/jukkak/mf/ra/parallel
