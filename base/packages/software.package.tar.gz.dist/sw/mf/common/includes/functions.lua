-- family("compilers")
-- whatis("Loads java")
io = require("io")
os = require("os")

local stdout = io.stdout

-- lua doesn't come with a trim function; package one ourselves
function trim(s)
  return (s:gsub("^%s*(.-)%s*$", "%1"))
end

--function log_to_syslog(a)
function log_to_syslog(mod_name) 
	local user = os.getenv("USER")
	local jobid = ""
	local slurmid = os.getenv("SLURM_JOB_ID")
	local msg2 = ""

	if slurmid != nil then
		jobid = ", jobid=" .. slurmid
	end		 

--	if a != "" then
--			msg2 = ", " .. a
--	end

	if mode() == "load" then
		local module_name = mod_name 
		local msg = user .. " loaded module " .. module_name .. msg2 .. jobid
		os.execute("/bin/bash -c '/usr/bin/logger -i -p local1.info " .. msg .."'")
	end	

	if mode() == "unload" then 
		local module_name = mod_name 
		local msg = "unloaded module " .. module_name
		os.execute("/bin/bash -c '/usr/bin/logger -i -p local1.info " .. msg .. "'")	
	end
end

function get_cluster()
	local Cluster
	local modules_cluster = os.getenv("MODULES_CLUSTER")

	if trim(modules_cluster) != "" then
		Cluster = modules_cluster
	else
		local cl = trim(capture("/bin/hostname -s | /usr/bin/tr -d 0-9"))
		local clm  = trim(capture("/bin/hostname -s | /usr/bin/tr -d m"))

		if cl == "i" then
			Cluster = "irma"
		elseif cl == "irma-q" then
			Cluster = "irma"
		elseif cl == "irma" then
			Cluster = "irma"
		elseif cl == "m" then
			Cluster = "milou"
		elseif cl == "milou" then
			Cluster = "milou"
		elseif cl == "milou-b" then
			Cluster = "milou"
		elseif cl == "milou-f" then
			Cluster = "milou" 
		elseif cl == "r" then
			Cluster = "rackham" 
		elseif cl == "rackham" then
			Cluster = "rackham" 
		else
			Cluster = "milou"
		end
	end
end

