# -*- lua -*-

scDescriptT = {
  {
    ["dir"] = "/sw/mf/cache/rackham",
    ["timestamp"] = false,
  },
}
